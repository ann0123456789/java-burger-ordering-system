import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * BillSummary panel displays the summary of the current order
 * It allows user to confirm or cancel order
 *
 * @author Lim Sweet Ann
 * @version 3.5
 */
public class BillSummary extends JPanel
{
    // reference to the main GUI frame
    private GuiInterface parentFrame;
    private JPanel billSummary;

    // gui components
    private JLabel billMessage;
    private JTextArea orderSummary;
    private JButton confirmButton;
    private JButton cancelButton;

    /**
     * Constructs the BillSummary panel
     *
     * @param parent GuiInterface frame that manages the screen transitions
     */
    public BillSummary(GuiInterface parent)
    {
        this.parentFrame = parent;

        // confirm order button
        confirmButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                parentFrame.showMainMenu();
            }
        });

        // cancel order button
        cancelButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                // clears the current order and return to main menu
                parentFrame.getOrderManager().removeLastOrder();
                parentFrame.clearCurrentOrder();
                parentFrame.showMainMenu();
            }
        });
    }

    /**
     * Used by GuiInterface to provide JPanel component of BillSummary panel
     *
     * @return main JPanel for BillSummary panel
     */
    public JPanel getBillSummary()
    {
        return billSummary;
    }

    /**
     * Displays the details of the given order in the text area
     *
     * @param order order to summarize / default message if no order exist
     */
    public void showOrderSummary(Order order)
    {
        String summary;
        if (order != null)
        {
            summary = order.toString();
        }
        else
        {
            summary = "No order to display.";
        }
        orderSummary.setText(summary);
    }
}
