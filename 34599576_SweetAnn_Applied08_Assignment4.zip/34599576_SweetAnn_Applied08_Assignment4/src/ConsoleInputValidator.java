import java.util.ArrayList;
import java.util.Scanner;

/**
 * ConsoleInputValidator is a utility class that handles user input validation
 *  for names, contact numbers, addresses and food choices in the system
 *  for console-based interaction
 *
 * @author Lim Sweet Ann
 * @version 2.3
 */
public class ConsoleInputValidator
{
    /**
     * Validates and returns a non-empty delivery address entered by the user
     *
     * @param scanner Scanner for reading user input
     * @return validated delivery address
     */
    public static String validateAddress(Scanner scanner)
    {
        String address;
        do
        {
            System.out.print("Delivery Address: ");
            address = scanner.nextLine().trim();
            if (address.isEmpty())
            {
                System.out.println("Delivery address cannot be empty!");
            }
        }
        while (address.isEmpty());
        return address;
    }

    /**
     * Validates and returns a contact number with conditions:
     * - non-empty
     * - start with +60
     * - more than 9 digits
     *
     * @param scanner Scanner for reading user input
     * @return validated contact number
     */
    public static String validateContact(Scanner scanner)
    {
        String contact;
        boolean validNumber = false;

        do
        {
            System.out.print("Contact Number (with country code, +60): ");
            contact = scanner.nextLine().trim();

            if (contact.isEmpty())
            {
                System.out.println("Contact number cannot be empty!");
            }
            // check for first 3 characters
            else if (!contact.startsWith("+60"))
            {
                System.out.println("Contact number must start with '+60'!");
            }
            else
            {
                String numberPart = contact.substring(1);
                try
                {
                    // avoid presence of character
                    Long.parseLong(numberPart);
                    if (numberPart.length() > 9)
                    {
                        // exit from loop
                        validNumber = true;
                    }
                    else
                    {
                        System.out.println("Contact number cannot " +
                                "be less than 10 digit!");
                    }
                }
                catch (NumberFormatException e)
                {
                    System.out.println("Contact number must contain " +
                            "digits only!");
                }
            }
        }
        while (!validNumber);

        return contact;
    }

    /**
     * Prompts the user to select a valid food option
     *
     * @param scanner Scanner for reading user input
     * @return validated food choice
     */
    public static int validateFoodChoice(Scanner scanner)
    {
        int foodChoice = 0;
        boolean validChoice = false;
        while (!validChoice)
        {
            System.out.print("Input your choice: ");
            String userInput = scanner.nextLine().trim();
            try
            {
                // avoid presence of character
                foodChoice = Integer.parseInt(userInput);
                if (foodChoice >= 1 && foodChoice <= 3)
                {
                    validChoice = true;
                }
                else
                {
                    System.out.println("Invalid option. " +
                            "Please enter 1, 2, or 3.");
                }
            }
            catch (NumberFormatException e)
            {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        return foodChoice;
    }

    /**
     * Validates and returns a non-empty customer name entered by the user
     *
     * @param scanner Scanner for reading user input
     * @return validated customer name
     */
    public static String validateName(Scanner scanner)
    {
        String name;
        do
        {
            System.out.print("Name: ");
            name = scanner.nextLine().trim();
            if (name.isEmpty())
            {
                System.out.println("Customer name cannot be empty!");
            }
        }
        while (name.isEmpty());
        return name;
    }

    /**
     * Validates pasta topping choice from user input
     *
     * @param scanner Scanner object for reading input
     * @param maxOption maximum valid option number (length of toppings array)
     * @return validated topping choice
     */
    public static int validatePastaToppingChoice(Scanner scanner,
                                                 int maxOption)
    {
        int toppingChoice = -1;
        boolean validChoice = false;

        do
        {
            System.out.print("Your topping choice: ");
            String userInput = scanner.nextLine();

            try
            {
                toppingChoice = Integer.parseInt(userInput);
                if (toppingChoice < 1 || toppingChoice > maxOption)
                {
                    System.out.println("Invalid choice. " +
                            "Please select between 1 and " + maxOption);
                }
                else
                {
                    validChoice = true;
                }
            }
            catch (NumberFormatException e)
            {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        while (!validChoice);

        return toppingChoice;
    }

    /**
     * Validates user's pizza topping choices
     *
     * @param scanner Scanner for reading user input
     * @return ArrayList of selected PizzaToppings
     */
    public static ArrayList<PizzaTopping> validatePizzaToppings(Scanner scanner)
    {
        ArrayList<PizzaTopping> toppings = new ArrayList<>();
        // get available toppings from enum class
        PizzaTopping[] allToppings = PizzaTopping.values();
        boolean finishAdd = false;

        while (!finishAdd)
        {
            System.out.print("Your topping choice (0 to stop): ");
            String userInput = scanner.nextLine();

            try
            {
                int toppingAdd = Integer.parseInt(userInput);
                if (toppingAdd == 0)
                {
                    finishAdd = true;
                }
                else if (toppingAdd >= 1 && toppingAdd <= allToppings.length)
                {
                    // getting correct index number for selected topping
                    PizzaTopping selectedTopping = allToppings[toppingAdd - 1];
                    toppings.add(selectedTopping);
                    System.out.println(selectedTopping.name() + " added.");
                }
                else
                {
                    System.out.println("Invalid option number! " +
                            "Please select between 1 and " +
                            allToppings.length);
                }
            }
            catch (NumberFormatException e)
            {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        return toppings;
    }
}