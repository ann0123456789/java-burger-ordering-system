import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * PizzaToppingSelection panel allows the user to select multiple
 *  pizza toppings and add the customized pizza to current order
 *
 * @author Lim Sweet Ann
 * @version 2.3
 */
public class PizzaToppingSelection extends JPanel
{
    // reference to the main GUI frame
    private GuiInterface parentFrame;
    private JPanel pizzaToppingSelection;

    // gui compenents
    private JLabel addToppingsMessage;
    private JCheckBox hamCheckBox;
    private JButton finishButton;
    private JCheckBox cheeseCheckBox;
    private JCheckBox mushroomCheckBox;
    private JCheckBox tomatoCheckBox;
    private JCheckBox seafoodCheckBox;
    private JCheckBox pineappleCheckBox;

    /**
     * Constructs the PizzaToppingSelection panel
     *
     * @param parent GuiInterface frame that manages the screen transitions
     */
    public PizzaToppingSelection(GuiInterface parent)
    {
        this.parentFrame = parent;

        // finish selected toppings button
        finishButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                ArrayList<PizzaTopping> selectedToppings = new ArrayList<>();

                // check each checkbox and add corresponding topping selected
                if (hamCheckBox.isSelected())
                {
                    selectedToppings.add(PizzaTopping.HAM);
                }
                if (cheeseCheckBox.isSelected())
                {
                    selectedToppings.add(PizzaTopping.CHEESE);
                }
                if (mushroomCheckBox.isSelected())
                {
                    selectedToppings.add(PizzaTopping.MUSHROOMS);
                }
                if (tomatoCheckBox.isSelected())
                {
                    selectedToppings.add(PizzaTopping.TOMATO);
                }
                if (seafoodCheckBox.isSelected())
                {
                    selectedToppings.add(PizzaTopping.SEAFOOD);
                }
                if (pineappleCheckBox.isSelected())
                {
                    selectedToppings.add(PizzaTopping.PINEAPPLE);
                }

                // create pizza object with selected toppings
                Pizza pizza = new Pizza("Pizza", selectedToppings);
                parentFrame.addFoodItem(pizza);

                JOptionPane.showMessageDialog(PizzaToppingSelection.this,
                        "Pizza added!\nToppings: " + selectedToppings,
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                parentFrame.showFoodItemMenu();
            }
        });
    }

    /**
     * Used by GuiInterface to provide JPanel component of
     * PizzaToppingSelection panel
     *
     * @return pizza topping selection panel
     */
    public JPanel getPizzaToppingSelection() {
        return pizzaToppingSelection;
    }
}
