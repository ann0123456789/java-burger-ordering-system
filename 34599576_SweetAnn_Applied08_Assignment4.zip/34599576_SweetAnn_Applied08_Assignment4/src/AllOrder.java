import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * AllOrder panel displays a list of all active orders
 *
 * @author Lim Sweet Ann
 * @version 2.3
 */
public class AllOrder extends JPanel
{
    // reference to the main GUI frame
    private GuiInterface parentFrame;
    private JPanel allOrder;

    // gui component
    private JLabel allOrderMessage;
    private JButton backButton;
    private JScrollPane orderScroll;
    private JTextArea orderTextArea;

    /**
     * Constructs the AllOrder panel
     *
     * @param parent GuiInterface frame that manages the screen transitions
     */
    public AllOrder(GuiInterface parent)
    {
        this.parentFrame = parent;

        // load and display all existing orders when the panel is created
        loadOrders();

        // back to main menu button
        backButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                parentFrame.showMainMenu();
            }
        });
    }

    /**
     * Used by GuiInterface to provide JPanel component of AllOrder panel
     *
     * @return main JPanel for AllOrder panel
     */
    public JPanel getAllOrder()
    {
        return allOrder;
    }

    /**
     * Loads all orders from OrderManager and displays them in the text area
     */
    public void loadOrders()
    {
        String ordersText = parentFrame.getOrderManager().getAllOrdersSummary();
        orderTextArea.setText(ordersText);
    }

}
