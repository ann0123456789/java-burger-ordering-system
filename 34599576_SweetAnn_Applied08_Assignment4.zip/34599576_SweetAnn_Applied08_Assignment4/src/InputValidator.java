/**
 * InputValidator is a utility class that handles user input validation
 *  for names, contact numbers, addresses and food choices in the system
 *  for graphical user interface (GUI)
 *
 * @author Lim Sweet Ann
 * @version 2.3
 */
public class InputValidator
{
    /**
     * Validates that the given address is not null or empty after trimming
     *
     * @param address address string to validate
     * @return true if the address is non-null and not empty; false otherwise
     */
    public static boolean validateAddress(String address)
    {
        return address != null && !address.trim().isEmpty();
    }

    /**
     * Validates and returns a contact number with conditions:
     * - non-empty
     * - start with +60
     * - more than 9 digits
     *
     * @param contact contact number string to validate
     * @return true if contact number meets all the criteria; false otherwise
     */
    public static boolean validateContact(String contact)
    {
        if (contact == null || contact.trim().isEmpty())
        {
            return false;
        }
        else if (!contact.startsWith("+60") || contact.length() <= 9)
        {
            return false;
        }
        else
        {
            String numberPart = contact.substring(1);
            try
            {
                Long.parseLong(numberPart);
                if (numberPart.length() > 9)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (NumberFormatException e)
            {
                return false;
            }
        }
    }

    /**
     * Validates that the given name is not null or empty after trimming
     *
     * @param name customer name to validate
     * @return true if the name is non-null and not empty; false otherwise
     */
    public static boolean validateName(String name)
    {
        return name != null && !name.trim().isEmpty();
    }
}

