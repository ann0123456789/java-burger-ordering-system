import java.util.ArrayList;

/**
 * OrderManager class used to manage a list of customer orders of restaurant
 * It allows adding new orders, delivering next order,
 *  printing all current orders and checking active orders
 *
 * @author Lim Sweet Ann
 * @version 3.1
 */
public class OrderManager
{
    private ArrayList<Order> orders;

    /**
     * Constructs a new OrderManager with an empty order list
     */
    public OrderManager()
    {
        orders = new ArrayList<>();
    }

    /**
     * Constructs a OrderManager with a given list of orders
     *
     * @param orders list of existing orders to initialize the manager with
     */
    public OrderManager(ArrayList<Order> orders)
    {
        if (orders != null)
        {
            this.orders = orders;
        }
        else
        {
            this.orders = new ArrayList<>();
        }
    }

    /**
     * Add new order to the list
     *
     * @param order Order object to be added
     */
    public void addOrder(Order order)
    {
        orders.add(order);
    }

    /**
     * Delivers (removes) the next order in the list
     *
     * @return delivered Order (null if the list is empty)
     */
    public Order deliverOrder()
    {
        if (orders.isEmpty())
        {
            return null;
        }
        // remove first element + return removed element
        return orders.remove(0);
    }

    /**
     * Generates a string summary of all orders
     * (used in GUI)
     *
     * @return formatted string with all order details
     */
    public String getAllOrdersSummary()
    {
        if (orders.isEmpty())
        {
            return "No orders to display.\n";
        }

        String ordersText = "";
        for (Order order : orders)
        {
            ordersText += order.toString() + "\n";
            ordersText += "-----------\n";
        }
        return ordersText;
    }

    // accessor method for orders
    public ArrayList<Order> getOrders()
    {
        return orders;
    }

    /**
     * Check for active orders
     *
     * @return true if there are one or more orders (false if no order)
     */
    public boolean hasOrders()
    {
        return !orders.isEmpty();
    }

    /**
     * Removes (cancels) the last order in the list
     *  (used in GUI system)
     */
    public void removeLastOrder()
    {
        if (!orders.isEmpty())
        {
            orders.remove(orders.size() - 1);
        }
    }

    // mutator/setter method for order
    public void setOrders(ArrayList<Order> orders)
    {
        if (orders != null)
        {
            this.orders = orders;
        }
        else
        {
            this.orders = new ArrayList<>();
        }
    }
}
