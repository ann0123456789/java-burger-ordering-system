import java.util.ArrayList;
import java.util.Scanner;

/**
 * The OrderSystem class handles interaction between user and takeaway system
 * This class interacts with the OrderManager, Customer and FoodItem classes
 * It handles user input and validation for customer details and menu selections
 *
 * @author Lim Sweet Ann
 * @version 6.2
 */
public class OrderSystem
{
    private OrderManager orderManager;
    private Scanner scanner;

    /**
     * Constructs a new OrderSystem instance
     */
    public OrderSystem()
    {
        // call for default constructor to initialize orderManager
        this.orderManager = new OrderManager();
        this.scanner = new Scanner(System.in);
    }

    /**
     * Constructs an OrderSystem with an existing OrderManager
     *
     * @param orderManager an existing OrderManager to use
     */
    public OrderSystem(OrderManager orderManager)
    {
        if (orderManager != null)
        {
            this.orderManager = orderManager;
        }
        else
        {
            this.orderManager = new OrderManager();
        }

        this.scanner = new Scanner(System.in);
    }

    /**
     * Handles the process of adding a new customer order,
     * including inputting customer details and selecting food items
     */
    public void addNewOrder()
    {
        System.out.println("\nEnter Customer Details:");

        // validate inputs using utility class created - ConsoleInputValidator
        String name = ConsoleInputValidator.validateName(scanner);
        String contact = ConsoleInputValidator.validateContact(scanner);
        String address = ConsoleInputValidator.validateAddress(scanner);

        Customer customer = new Customer(name, contact, address);

        ArrayList<FoodItem> foodItems = new ArrayList<>();

        // allow user to add multiple food items in 1 order
        boolean addingItems = true;
        while (addingItems)
        {
            System.out.println("\nSelect Food Item to add:");
            System.out.println("1. Pizza");
            System.out.println("2. Pasta");
            System.out.println("3. Done adding items");

            int foodChoice = ConsoleInputValidator.validateFoodChoice(scanner);

            switch (foodChoice)
            {
                case 1:
                    FoodItem pizza = createPizza();
                    if (pizza != null)
                    {
                        foodItems.add(pizza);
                        System.out.println("Pizza added.");
                    }
                    break;
                case 2:
                    FoodItem pasta = createPasta();
                    if (pasta != null)
                    {
                        foodItems.add(pasta);
                        System.out.println("Pasta added.");
                    }
                    break;
                case 3:
                    addingItems = false;
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        }

        if (foodItems.isEmpty())
        {
            System.out.println("No food items added. Order cancelled.");
        }
        else
        {
            Order order = new Order(customer, foodItems);
            orderManager.addOrder(order);
            System.out.println("\nOrder added:\n" + order);
        }
    }

    /**
     * Creates a new Pasta object by prompting the user
     * to select one topping
     *
     * @return a new Pasta object with selected topping
     */
    public FoodItem createPasta()
    {
        System.out.println("Select pasta topping:");

        // get available toppings from enum class to show available choice
        PastaTopping[] allToppings = PastaTopping.values();
        int toppingIndex = 1;
        for (PastaTopping topping : allToppings)
        {
            System.out.println(toppingIndex + " " + topping.name() +
                    " $" + topping.getPrice());
            toppingIndex++;
        }

        // use the validator method for input and validation
        int toppingChoice = ConsoleInputValidator
                .validatePastaToppingChoice(scanner, allToppings.length);

        // getting correct index number for selected topping
        PastaTopping selectedTopping = allToppings[toppingChoice - 1];
        System.out.println(selectedTopping.name() + " selected.");

        // create new pasta object with validated topping
        return new Pasta("Pasta", selectedTopping);
    }

    /**
     * Creates a new Pizza object by prompting the user
     * to select toppings
     *
     * @return a new Pizza object with selected toppings
     */
    public FoodItem createPizza()
    {
        System.out.println("Add pizza toppings:");
        // get available toppings from enum class to show available choice
        PizzaTopping[] allToppings = PizzaTopping.values();
        int toppingIndex = 1;
        for (PizzaTopping topping : allToppings)
        {
            System.out.println(toppingIndex + " " + topping.name() +
                    " $" + topping.getPrice());
            toppingIndex++;
        }

        // get validated topping lists
        ArrayList<PizzaTopping> toppings =
                ConsoleInputValidator.validatePizzaToppings(scanner);

        // create new pizza object with validated topping lists
        return new Pizza("Pizza", toppings);
    }

    /**
     * Delivers the next order in the queue
     */
    public void deliverOrder()
    {
        if (!orderManager.hasOrders())
        {
            System.out.println("No orders to deliver.");
        }
        else
        {
            Order delivered = orderManager.deliverOrder();
            System.out.println("\nDelivering Order:\n" + delivered);
        }
    }

    /**
     * Run the main program
     *
     * @param args command-line arguments
     */
    public static void main(String[] args)
    {
        OrderSystem system = new OrderSystem();
        system.mainMenu();
    }

    /**
     * Displays the main menu loop, allowing the user to
     * select options until they choose to exit
     */
    public void mainMenu()
    {
        int choice = 0;
        do
        {
            printMenu();
            System.out.print("Enter your choice: ");
            String userChoice = scanner.nextLine();

            // handle invalid input
            try
            {
                // avoid character input
                choice = Integer.parseInt(userChoice);
                switch (choice)
                {
                    case 1:
                        addNewOrder();
                        break;
                    case 2:
                        deliverOrder();
                        break;
                    case 3:
                        printAllOrders();
                        break;
                    case 4:
                        System.out.println("Exiting program...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please select 1-4.");
                }
            }
            catch (NumberFormatException e)
            {
                System.out.println("Invalid input. Please enter a number!");
            }
        }
        while (choice != 4);
    }

    /**
     * Prints all current orders in the system.
     */
    public void printAllOrders()
    {
        System.out.println("\nAll Current Orders:");
        System.out.print(orderManager.getAllOrdersSummary());
    }

    /**
     * Prints the main menu options to the console
     */
    public void printMenu()
    {
        System.out.println("\n--- Takeaway Order System Menu ---");
        System.out.println("1. Enter new customer order");
        System.out.println("2. Deliver order");
        System.out.println("3. Print all orders");
        System.out.println("4. Exit");
    }
}

