import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * PastaToppingSelection panel allows the user to select one pasta topping
 *  using radio buttons and add the pasta item to the current order
 *
 * @author Lim Sweet Ann
 * @version 2.3
 */
public class PastaToppingSelection extends JPanel
{
    // reference to the main GUI frame
    private GuiInterface parentFrame;
    private JPanel pastaToppingSelection;

    // gui components
    private JLabel selectMessage;
    private JRadioButton bologneseButton;
    private JRadioButton marinaraButton;
    private JRadioButton primaveraButton;
    private JRadioButton tomatoButton;
    private JButton finishButton;
    private JRadioButton noneButton;

    /**
     * Constructs the PastaToppingSelection panel
     *
     * @param parent GuiInterface frame that manages the screen transitions
     */
    public PastaToppingSelection(GuiInterface parent)
    {
        this.parentFrame = parent;

        // group the radio buttons so only one can be selected at a time
        ButtonGroup group = new ButtonGroup();
        group.add(bologneseButton);
        group.add(marinaraButton);
        group.add(primaveraButton);
        group.add(tomatoButton);
        group.add(noneButton);

        // finish select topping button
        finishButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {

                PastaTopping selectedTopping = null;
                // check which topping was selected
                if (bologneseButton.isSelected())
                {
                    selectedTopping = PastaTopping.BOLOGNESE;
                }
                else if (marinaraButton.isSelected())
                {
                    selectedTopping = PastaTopping.MARINARA;
                }
                else if (primaveraButton.isSelected())
                {
                    selectedTopping = PastaTopping.PRIMAVERA;
                }
                else if (tomatoButton.isSelected())
                {
                    selectedTopping = PastaTopping.TOMATO;
                }
                else if (noneButton.isSelected())
                {
                    selectedTopping = PastaTopping.NONE;
                }

                if (selectedTopping != null)
                {
                    // create a Pasta object and add it to the order
                    Pasta pasta = new Pasta("Pasta", selectedTopping);
                    parentFrame.addFoodItem(pasta);

                    JOptionPane.showMessageDialog(PastaToppingSelection.this,
                            "Pasta added!\nToppings: " + selectedTopping,
                            "Success", JOptionPane.INFORMATION_MESSAGE);
                    parentFrame.showFoodItemMenu();
                }
                else
                {
                    // remind user to select topping
                    JOptionPane.showMessageDialog(PastaToppingSelection.this,
                            "Please select a topping!");
                }
            }
        });
    }

    /**
     * Used by GuiInterface to provide JPanel component of
     *  PastaToppingSelection panel
     *
     * @return pasta topping selection panel
     */
    public JPanel getPastaToppingSelection()
    {
        return pastaToppingSelection;
    }
}
