import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * GuiInterface class provides a graphical user interface that
 *  allows user to interact with the system through screen/window navigation
 *
 * @author Lim Sweet Ann
 * @version 8.3
 */
public class GuiInterface extends JFrame
{
    private Customer currentCustomer;
    private ArrayList<FoodItem> currentFoodItems = new ArrayList<>();
    private OrderManager orderManager;

    // panels for different screens
    private FoodItemMenu foodItemMenuPanel;
    private BillSummary billSummaryPanel;

    // gui component
    private JLabel welcome;
    private JPanel customerOrderMenu;
    private JPanel mainMenu;
    private JButton newOrderButton;
    private JButton exitButton;
    private JButton deliverButton;
    private JButton printButton;

    /**
     * Constructs and initializes the GUI interface
     */
    public GuiInterface()
    {
        orderManager = new OrderManager();
        billSummaryPanel = new BillSummary(GuiInterface.this);
        foodItemMenuPanel = new FoodItemMenu(GuiInterface.this,
                orderManager, billSummaryPanel);

        // set up the main menu GUI content pane and window properties
        setContentPane(mainMenu);
        setTitle("Takeaway Order Management System");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(500, 400);
        setLocationRelativeTo(null);
        setVisible(true);

        // add action listeners for buttons
        // add new order button
        newOrderButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                CustomerOrderMenu customerOrderMenuPanel =
                        new CustomerOrderMenu(GuiInterface.this);
                setContentPane(customerOrderMenuPanel.getCustomerOrderMenu());
                revalidate();
                repaint();
            }
        });

        // deliver order button
        deliverButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                deliveringOrder();
            }
        });

        // view all order button
        printButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                AllOrder allOrderPanel = new AllOrder(GuiInterface.this);
                setContentPane(allOrderPanel.getAllOrder());
                revalidate();
                repaint();
            }
        });

        // exit button to end program
        exitButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                System.exit(0);
            }
        });

    }

    /**
     * Add food item to the current customer's order
     *
     * @param item food item to add
     */
    public void addFoodItem(FoodItem item)
    {
        this.currentFoodItems.add(item);
    }

    /**
     * Clears the current customer and food item selections
     *  for new order / canceled order
     */
    public void clearCurrentOrder()
    {
        this.currentCustomer = null;
        this.currentFoodItems.clear();
    }

    /**
     * Handles the delivery of the next order in the queue
     */
    public void deliveringOrder()
    {
        if (!orderManager.hasOrders())
        {
            // pop up message for informing status of order delivered/no order
            JOptionPane.showMessageDialog(GuiInterface.this,
                    "No orders to deliver.",
                    "Delivery Status",
                    JOptionPane.INFORMATION_MESSAGE);
        }
        else
        {
            Order delivered = orderManager.deliverOrder();
            JOptionPane.showMessageDialog(GuiInterface.this,
                    "Delivering Order:\n" + delivered,
                    "Delivery Status",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * Retrieves the system's order manager
     *
     * @return order manager instance
     */
    public OrderManager getOrderManager()
    {
        return orderManager;
    }

    /**
     * Main method to start the GUI application
     *
     * @param args command-line arguments
     */
    public static void main(String[] args)
    {
        new GuiInterface();
    }

    /**
     * Stores the provided customer details for the current session
     *
     * @param customer current order's customer
     */
    public void processCustomer(Customer customer)
    {
        this.currentCustomer = customer;
    }

    /**
     * Displays the bill summary screen
     *
     * @param order completed order to summarize
     */
    public void showBillSummary(Order order)
    {
        billSummaryPanel.showOrderSummary(order);
        setContentPane(billSummaryPanel.getBillSummary());
        revalidate();
        repaint();
    }

    /**
     * Displays the food item selection menu
     */
    public void showFoodItemMenu()
    {
        // pass the current customer and selected items to the panel
        foodItemMenuPanel.setOrderDetails(currentCustomer, currentFoodItems);
        setContentPane(foodItemMenuPanel.getFoodItemMenuPanel());
        revalidate();
        repaint();
    }

    /**
     * Return back to main menu
     */
    public void showMainMenu()
    {
        setContentPane(mainMenu);
        revalidate();
        repaint();
    }

    /**
     * Displays the pasta topping selection panel
     */
    public void showPastaToppingSelection()
    {
        PastaToppingSelection pastaOrder =
                new PastaToppingSelection(GuiInterface.this);
        setContentPane(pastaOrder.getPastaToppingSelection());
        revalidate();
        repaint();
    }

    /**
     * Displays the pizza topping selection panel
     */
    public void showPizzaToppingSelection()
    {
        PizzaToppingSelection pizzaOrder =
                new PizzaToppingSelection(GuiInterface.this);
        setContentPane(pizzaOrder.getPizzaToppingSelection());
        revalidate();
        repaint();
    }
}
