import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * CustomerOrderMenu panel handles customer input for name, contact and address
 *
 * @author Lim Sweet Ann
 * @version 2.3
 */
public class CustomerOrderMenu extends JPanel
{
    // reference to the main GUI frame
    private GuiInterface parentFrame;
    private JPanel customerOrderMenu;

    // gui components
    private JLabel enterMessage;
    private JTextField nameInput;
    private JLabel customerName;
    private JLabel contact;
    private JLabel address;
    private JTextField contactInput;
    private JTextField addressInput;
    private JButton submitButton;
    private JButton cancelButton;

    /**
     * Constructs the CustomerOrderMenu panel
     *
     * @param parent GuiInterface frame that manages the screen transitions
     */
    public CustomerOrderMenu(GuiInterface parent)
    {
        this.parentFrame = parent;

        // cancel button action
        cancelButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                // return to main menu
                parentFrame.showMainMenu();
            }
        });

        // submit button action
        submitButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String name = nameInput.getText();
                String contact = contactInput.getText();
                String address = addressInput.getText();

                // validate inputs using utility class developed - InputValidator
                if (!InputValidator.validateName(name))
                {
                    JOptionPane.showMessageDialog(CustomerOrderMenu.this,
                            "Customer name cannot be empty!", "Input Error",
                            JOptionPane.ERROR_MESSAGE);
                    nameInput.setText("");
                }
                else if (!InputValidator.validateContact(contact))
                {
                    JOptionPane.showMessageDialog(CustomerOrderMenu.this,
                            "Invalid contact number! It must: \nstart with " +
                                    "'+60', have digits only and " +
                                    "at least 10 digits!",
                            "Input Error", JOptionPane.ERROR_MESSAGE);
                    contactInput.setText("");
                }
                else if (!InputValidator.validateAddress(address))
                {
                    JOptionPane.showMessageDialog(CustomerOrderMenu.this,
                            "Delivery address cannot be empty!", "Input Error",
                            JOptionPane.ERROR_MESSAGE);
                    addressInput.setText("");
                }
                // save customer information if all inputs are valid
                else
                {
                    Customer customer = new Customer(name, contact, address);
                    // pass to main GUI to save customer information
                    parentFrame.processCustomer(customer);

                    // pop up message after successful registration
                    JOptionPane.showMessageDialog(
                            CustomerOrderMenu.this,
                            "Customer details accepted!\n\n" +
                                    "Name: " + customer.getName() + "\n" +
                                    "Contact: " + customer.getContactNumber() +
                                    "\nAddress: " +
                                    customer.getDeliveryAddress(),
                            "Success",
                            JOptionPane.INFORMATION_MESSAGE);

                    clearInputs();
                    // proceed to the food selection frame
                    parentFrame.showFoodItemMenu();
                }
            }
        });
    }

    /**
     * Clears all the input fields on the panel
     */
    public void clearInputs()
    {
        nameInput.setText("");
        contactInput.setText("");
        addressInput.setText("");
    }

    /**
     * Used by GuiInterface to provide JPanel component of CustomerOrderMenu
     *
     * @return main JPanel for CustomerOrderMenu
     */
    public JPanel getCustomerOrderMenu()
    {
        return customerOrderMenu;
    }
}
