import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * FoodItemMenu panel allows the user to select food items (pizza or pasta)
 *  or finalize the order
 *
 * @author Lim Sweet Ann
 * @version 3.2
 */
public class FoodItemMenu extends JPanel
{
    // reference to the main GUI frame
    private GuiInterface parentFrame;
    private Customer customer;
    private ArrayList<FoodItem> foodItems;
    private OrderManager orderManager;
    private BillSummary billSummaryPanel;
    private JPanel foodItemMenuPanel;

    // gui components
    private JButton pizzaButton;
    private JButton pastaButton;
    private JButton finishButton;
    private JLabel selectMessage;

    /**
     * Constructs a FoodItemMenu panel
     *
     * @param parent GuiInterface frame that manages the screen transitions
     * @param orderManager system managing all orders
     * @param billSummaryPanel panel to show order summaries
     */
    public FoodItemMenu(GuiInterface parent, OrderManager orderManager,
                        BillSummary billSummaryPanel)
    {
        this.parentFrame = parent;
        this.orderManager = orderManager;
        this.billSummaryPanel = billSummaryPanel;

        // add pizza button
        pizzaButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                parentFrame.showPizzaToppingSelection();
            }
        });

        // add pasta button
        pastaButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                parentFrame.showPastaToppingSelection();
            }
        });

        // finalize order button
        finishButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                // if no customer or no items added will return to main menu
                if (customer == null || foodItems == null || foodItems.isEmpty())
                {
                    JOptionPane.showMessageDialog(FoodItemMenu.this,
                            "No customer or food items to create order.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    parentFrame.showMainMenu();
                }
                else
                {
                    // create new order with customer and food items
                    Order order = new Order(customer, foodItems);
                    orderManager.addOrder(order);

                    // update and proceed to bill summary panel
                    billSummaryPanel.showOrderSummary(order);
                    parentFrame.showBillSummary(order);
                    parentFrame.clearCurrentOrder();
                }
            }
        });
    }

    /**
     * Used by GuiInterface to provide JPanel component of FoodItem panel
     *
     * @return food item menu panel
     */
    public JPanel getFoodItemMenuPanel()
    {
        return foodItemMenuPanel;
    }

    /**
     * Set the customer and food items for the current order
     *
     * @param customer customer placing the order
     * @param foodItems list of food item selected by current customer
     */
    public void setOrderDetails(Customer customer,
                                ArrayList<FoodItem> foodItems)
    {
        this.customer = customer;
        this.foodItems = foodItems;
    }
}
